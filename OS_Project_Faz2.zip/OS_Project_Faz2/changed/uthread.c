#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2

#define STACK_SIZE  8192
#define MAX_THREAD  4


struct context {
    uint64 ra;
    uint64 sp;


    uint64 s0;
    uint64 s1;
    uint64 s2;
    uint64 s3;
    uint64 s4;
    uint64 s5;
    uint64 s6;
    uint64 s7;
    uint64 s8;
    uint64 s9;
    uint64 s10;
    uint64 s11;
};

struct thread {
    char       stack[STACK_SIZE];
    int        state;
    struct context context;
};
struct thread all_thread[MAX_THREAD];
struct thread *current_thread;
extern void thread_switch(struct context*, struct context*);

void
thread_init(void)
{

    current_thread = &all_thread[0];
    current_thread->state = RUNNING;
}

void
thread_schedule(void)
{
    struct thread *t, *next_thread;


            next_thread = 0;
    t = current_thread + 1;
    for(int i = 0; i < MAX_THREAD; i++){
        if(t >= all_thread + MAX_THREAD)
            t = all_thread;
        if(t->state == RUNNABLE) {
            next_thread = t;
            break;
        }
        t = t + 1;
    }

    if (next_thread == 0) {
        printf("thread_schedule: no runnable threads\n");
        exit(-1);
    }

    if (current_thread != next_thread) {
                next_thread->state = RUNNING;
        t = current_thread;
        current_thread = next_thread;

                thread_switch(&t->context, &current_thread->context);
    } else
        next_thread = 0;
}

void
thread_create(void (*func)())
{
    struct thread *t;

    for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
        if (t->state == FREE) break;
    }
    t->state = RUNNABLE;

            memset(&t->context, 0, sizeof t->context);
    t->context.ra = (uint64)func;

            t->context.sp = (uint64)(t->stack + STACK_SIZE);
}

void
thread_yield(void)
{
    current_thread->state = RUNNABLE;
    thread_schedule();
}

volatile int a_started, b_started, c_started;
volatile int a_n, b_n, c_n;

void
thread_a(void)
{
    printf("thread_a started\n");
    int start = uptime();
    int end = 1000000;
    for (int i = 0; i < end; i++) {
        a_n += 1;
        if(uptime() - start > 10) {
            printf("thread_a %d\n", i);
            thread_yield();
            start = uptime();
        }

    }
    printf("thread_a: exit after %d\n", a_n);

    current_thread->state = FREE;
    thread_schedule();
}

void
thread_b(void)
{
    printf("thread_b started\n");
    int end = 1000000;
    int start = uptime();
    for (int i = 0; i < end; i++) {
        b_n += 1;
        if(uptime() - start > 10) {
            printf("thread_b %d\n", i);
            thread_yield();
            start = uptime();
        }

    }
    printf("thread_b: exit after %d\n", b_n);

    current_thread->state = FREE;
    thread_schedule();
}

void
thread_c(void)
{

    int end = 1000000;
    printf("thread_c started\n");
    int start = uptime();
    for (int i = 0; i < end; i++) {
        c_n += 1;
        if(uptime() - start > 10) {
            printf("thread_c %d\n", i);
            thread_yield();
            start = uptime();
        }

    }
    printf("thread_c: exit after %d\n", c_n);

    current_thread->state = FREE;
    thread_schedule();
}

int
main(int *argc, char **argv[])
{
    a_n = b_n = c_n = 0;
    thread_init();
    thread_create(thread_a);
    thread_create(thread_b);
    thread_create(thread_c);
    thread_schedule();
    exit(0);
}






//----------------------------------------------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------
//
//
//#define THREAD_STATE_FREE    0x0
//#define THREAD_STATE_RUNNING 0x1
//#define THREAD_STATE_RUNNABLE 0x2
//
//#define THREAD_STACK_SIZE  8192
//#define MAX_THREADS  4
//
//typedef struct {
//    int sp;
//    char stack[THREAD_STACK_SIZE];
//    int state;
//} Thread;
//
//static Thread allThreads[MAX_THREADS];
//Thread *currentThread;
//Thread *nextThread;
//
//extern void threadSwitch(void);
//
//void initThreads(void) {
//    currentThread = &allThreads[0];
//    currentThread->state = THREAD_STATE_RUNNING;
//}
//
//static void scheduleThread(void) {
//    nextThread = 0;
//
//    for (Thread *t = allThreads; t < allThreads + MAX_THREADS; t++) {
//        if (t->state == THREAD_STATE_RUNNABLE && t != currentThread) {
//            nextThread = t;
//            break;
//        }
//    }
//
//    if (nextThread == 0 && currentThread->state == THREAD_STATE_RUNNABLE) {
//        nextThread = currentThread;
//    }
//
//    if (nextThread == 0) {
//        printf(2, "scheduleThread: no runnable threads\n");
//        exit();
//    }
//
//    if (currentThread != nextThread) {
//        nextThread->state = THREAD_STATE_RUNNING;
//        threadSwitch();
//    } else {
//        nextThread = 0;
//    }
//}
//
//void createThread(void (*func)()) {
//    Thread *newThread;
//
//    for (newThread = allThreads; newThread < allThreads + MAX_THREADS; newThread++) {
//        if (newThread->state == THREAD_STATE_FREE) {
//            break;
//        }
//    }
//
//    newThread->sp = (int)(newThread->stack + THREAD_STACK_SIZE);
//    newThread->sp -= 4;
//    *((int *)(newThread->sp)) = (int)func;
//    newThread->sp -= 32;
//    newThread->state = THREAD_STATE_RUNNABLE;
//}
//
//void yieldThread(void) {
//    currentThread->state = THREAD_STATE_RUNNABLE;
//    scheduleThread();
//}
//
//static void threadFunction(void) {
//    int i;
//
//    printf(1, "thread running\n");
//
//    for (i = 0; i < 100; i++) {
//        printf(1, "thread 0x%x\n", (int)currentThread);
//        yieldThread();
//    }
//
//    printf(1, "thread: exit\n");
//    currentThread->state = THREAD_STATE_FREE;
//    scheduleThread();
//}
//
//int main(int argc, char *argv[]) {
//    initThreads();
//    createThread(threadFunction);
//    createThread(threadFunction);
//    scheduleThread();
//
//    return 0;
//}
