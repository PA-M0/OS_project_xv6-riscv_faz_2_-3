//
// Created by soheil on 1/28/24.
//

// test.c

// test.c

#include "kernel/types.h"
#include "user.h"

void long_running_task(int pid) {
    int i;
    for (i = 1; i <= 10000000; i++) {
        // Print message indicating the process number and current count
        printf("Process %d (pid %d) is running: %d\n", pid % 10, pid, i);

        // Simulaste some CPU-intensive task
        asm("nop");
    }

    // Print message indicating that the process has completed
    printf("Process %d (pid %d) has completed\n", pid % 10, pid);
}

int main() {
    int i, pid;

    // Create 10 processes
    for (i = 1; i <= 10; i++) {
        pid = fork();
        if (pid == 0) {
            // Child process
            long_running_task(getpid());
            exit(0);
        }
    }

    // Wait for all child processes to complete
    for (i = 1; i <= 10; i++) {
        wait(0);
    }

    exit(0);
}
